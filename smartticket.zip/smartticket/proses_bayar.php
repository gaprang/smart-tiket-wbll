<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

$ticketTypeId = (int)($_POST['ticket_type_id'] ?? 0);
$nama         = trim($_POST['nama'] ?? '');
$email        = trim($_POST['email'] ?? '');
$phone        = trim($_POST['phone'] ?? '');
$jumlah       = (int)($_POST['jumlah'] ?? 0);

if ($ticketTypeId <= 0 || $nama === '' || $email === '' || $jumlah <= 0) {
    die('Data tidak valid.');
}

// ambil data tiket
$stmt = $conn->prepare("SELECT harga, nama_tiket FROM ticket_types WHERE id = ?");
$stmt->bind_param('i', $ticketTypeId);
$stmt->execute();
$ticket = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$ticket) {
    die('Jenis tiket tidak ditemukan.');
}

$hargaSatuan = (int)$ticket['harga'];
$totalHarga  = $hargaSatuan * $jumlah;
$now         = date('Y-m-d H:i:s');

// simpan ke tabel orders
$stmt = $conn->prepare("INSERT INTO orders (nama_pelanggan, email, ticket_type_id, jumlah_tiket, total_harga, created_at) 
                        VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param('ssiiis', $nama, $email, $ticketTypeId, $jumlah, $totalHarga, $now);
$stmt->execute();
$orderId = $stmt->insert_id;
$stmt->close();

// generate tiket per orang
$stmtTicket = $conn->prepare("INSERT INTO tickets (order_id, qr_code_token, status, created_at) VALUES (?, ?, 'VALID', ?)");
for ($i = 0; $i < $jumlah; $i++) {
    // token unik sederhana (cukup untuk tugas)
    $token = 'TK-' . $orderId . '-' . strtoupper(bin2hex(random_bytes(3))) . '-' . ($i + 1);
    $stmtTicket->bind_param('iss', $orderId, $token, $now);
    $stmtTicket->execute();
}
$stmtTicket->close();

// redirect ke halaman tampil tiket
header('Location: tampil_tiket.php?order_id=' . $orderId);
exit;
