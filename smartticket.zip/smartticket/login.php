<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login Pelanggan - SmartTicket</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="main-wrapper">
    <div class="card">
        <div class="app-header">
            <div>
                <div class="badge badge-primary">Login</div>
                <h1 class="app-title">Login Pelanggan</h1>
                <p class="app-subtitle">Masukkan email yang kamu gunakan saat pemesanan.</p>
            </div>
            <div>
                <a href="index.php" class="btn btn-outline">← Beranda</a>
            </div>
        </div>

        <form action="cek_status.php" method="get">
            <div class="form-group">
                <label class="label" for="email">Email</label>
                <input class="input" type="email" id="email" name="email"
                       placeholder="emailkamu@example.com" required>
            </div>
            <p class="text-muted small">
                *Untuk versi tugas ini, login hanya digunakan sebagai contoh tampilan.
                Pengecekan tiket tetap bisa dilakukan dari halaman <strong>Cek Status Tiket</strong>.
            </p>
            <button type="submit" class="btn btn-primary">Lanjut</button>
        </form>
    </div>
</div>
</body>
</html>
