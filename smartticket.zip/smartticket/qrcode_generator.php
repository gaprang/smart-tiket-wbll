<?php
require 'db.php';
require 'phpqrcode/qrlib.php'; // pastikan path ini sesuai

$token = $_GET['token'] ?? '';

header('Content-Type: image/png');

if ($token === '') {
    QRcode::png('TOKEN KOSONG');
    exit;
}

// kamu bisa menambahkan level error & ukuran jika mau
QRcode::png($token, null, QR_ECLEVEL_M, 4);
