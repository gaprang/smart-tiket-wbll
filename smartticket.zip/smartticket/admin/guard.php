<?php
session_start();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    // kalau bukan admin / belum login → balik ke halaman login utama
    header('Location: ../index.php');
    exit;
}
