<?php
require 'guard.php';
require '../db.php';

// set USED manual
if (isset($_GET['set_used'])) {
    $id  = (int)$_GET['set_used'];
    $now = date('Y-m-d H:i:s');
    $stmt = $conn->prepare("UPDATE tickets SET status = 'USED', created_at = ? WHERE id = ?");
    $stmt->bind_param('si', $now, $id);
    $stmt->execute();
    $stmt->close();

    header('Location: manajemen_penggunaan.php');
    exit;
}

$sql = "SELECT t.*, o.nama_pelanggan 
        FROM tickets t
        JOIN orders o ON t.order_id = o.id
        ORDER BY t.created_at DESC";
$list = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Penggunaan Tiket - SmartTicket</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="main-wrapper">
    <div class="card">
        <div class="app-header">
            <div>
                <div class="badge badge-primary">Admin</div>
                <h1 class="app-title">Manajemen Penggunaan Tiket</h1>
                <p class="app-subtitle">Pantau status tiket (VALID / USED) dan perbaiki jika perlu.</p>
            </div>
            <div>
                <a href="index.php" class="btn btn-outline">← Dashboard</a>
            </div>
        </div>

        <table class="table">
            <thead>
            <tr>
                <th>Token</th>
                <th>Pemilik</th>
                <th>Status</th>
                <th>Dipakai Pada</th>
                <th class="text-center">Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($list && $list->num_rows): ?>
                <?php while ($row = $list->fetch_assoc()): ?>
                    <tr>
                        <td class="small"><?= htmlspecialchars($row['qr_code_token']); ?></td>
                        <td><?= htmlspecialchars($row['nama_pelanggan']); ?></td>
                        <td>
                            <?php if ($row['status'] === 'VALID'): ?>
                                <span class="chip chip-success">VALID</span>
                            <?php else: ?>
                                <span class="chip chip-warning">USED</span>
                            <?php endif; ?>
                        </td>
                        <td><?= $row['created_at']; ?></td>
                        <td class="text-center">
                            <?php if ($row['status'] === 'VALID'): ?>
                                <a class="btn btn-outline"
                                   href="manajemen_penggunaan.php?set_used=<?= $row['id']; ?>"
                                   onclick="return confirm('Jadikan status tiket ini menjadi DIPAKAI??');">
                                    Tandai Dipakai
                                </a>
                            <?php else: ?>
                                <span class="text-muted small">-</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="5" class="text-center text-muted">Belum ada tiket.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
