<?php
require 'guard.php';
require '../db.php';

// ambil ringkasan
$totalTiketJenis   = $conn->query("SELECT COUNT(*) AS jml FROM ticket_types")->fetch_assoc()['jml'] ?? 0;
$totalOrder        = $conn->query("SELECT COUNT(*) AS jml FROM orders")->fetch_assoc()['jml'] ?? 0;
$totalTiketUsed    = $conn->query("SELECT COUNT(*) AS jml FROM tickets WHERE status = 'USED'")->fetch_assoc()['jml'] ?? 0;
$totalTiketValid   = $conn->query("SELECT COUNT(*) AS jml FROM tickets WHERE status = 'VALID'")->fetch_assoc()['jml'] ?? 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin - SmartTicket</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="main-wrapper">
    <div class="card">
        <div class="app-header">
            <div>
                <div class="badge badge-primary">Admin Panel</div>
                <h1 class="app-title">Dashboard SmartTicket</h1>
                <p class="app-subtitle">Kelola tiket dan pantau pengunjung event.</p>
            </div>
            <div>
                <a href="../logout.php" class="btn btn-outline">Logout</a>
            </div>
        </div>

        <div class="nav-top">
            <a href="manajemen_tiket.php">Manajemen Tiket</a>
            <a href="manajemen_pesanan.php">Manajemen Pesanan</a>
            <a href="manajemen_penggunaan.php">Penggunaan Tiket</a>
            <a href="laporan.php">Laporan</a>
        </div>

        <div class="summary-box mt-3">
            <div class="summary-item">
                <div class="summary-label">Jenis Tiket</div>
                <div class="summary-value"><?= $totalTiketJenis; ?></div>
            </div>
            <div class="summary-item">
                <div class="summary-label">Total Pesanan</div>
                <div class="summary-value"><?= $totalOrder; ?></div>
            </div>
            <div class="summary-item">
                <div class="summary-label">Tiket Terpakai</div>
                <div class="summary-value"><?= $totalTiketUsed; ?></div>
            </div>
            <div class="summary-item">
                <div class="summary-label">Tiket Masih VALID</div>
                <div class="summary-value"><?= $totalTiketValid; ?></div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
