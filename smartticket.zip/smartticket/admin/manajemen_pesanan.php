<?php
require 'guard.php';
require '../db.php';

$sql = "SELECT o.*, t.nama_tiket 
        FROM orders o
        JOIN ticket_types t ON o.ticket_type_id = t.id
        ORDER BY o.created_at DESC";
$list = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen Pesanan - SmartTicket</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="main-wrapper">
    <div class="card">
        <div class="app-header">
            <div>
                <div class="badge badge-primary">Admin</div>
                <h1 class="app-title">Manajemen Pesanan</h1>
                <p class="app-subtitle">Lihat semua pesanan yang masuk dari pelanggan.</p>
            </div>
            <div>
                <a href="index.php" class="btn btn-outline">← Dashboard</a>
            </div>
        </div>

        <table class="table">
            <thead>
            <tr>
                <th>Waktu</th>
                <th>Nama</th>
                <th>Email</th>
                <th>Jenis Tiket</th>
                <th>Jumlah</th>
                <th>Total</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($list && $list->num_rows): ?>
                <?php while ($row = $list->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['created_at']; ?></td>
                        <td><?= htmlspecialchars($row['nama_pelanggan']); ?></td>
                        <td><?= htmlspecialchars($row['email']); ?></td>
                        <td><?= htmlspecialchars($row['nama_tiket']); ?></td>
                        <td><?= $row['jumlah_tiket']; ?></td>
                        <td>Rp <?= number_format($row['total_harga'], 0, ',', '.'); ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6" class="text-center text-muted">Belum ada pesanan.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
