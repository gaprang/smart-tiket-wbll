<?php
require 'guard.php';
require '../db.php';

$editTicket = null;
$message    = '';

// hapus
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $conn->query("DELETE FROM ticket_types WHERE id = $id");
    header('Location: manajemen_tiket.php');
    exit;
}

// ambil data untuk edit
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM ticket_types WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $editTicket = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// simpan (tambah / update)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id         = (int)($_POST['id'] ?? 0);
    $nama       = trim($_POST['nama_tiket'] ?? '');
    $harga      = (int)($_POST['harga'] ?? 0);
    $deskripsi  = trim($_POST['deskripsi'] ?? '');

    if ($nama === '' || $harga <= 0) {
        $message = 'Nama dan harga wajib diisi.';
    } else {
        if ($id > 0) {
            $stmt = $conn->prepare("UPDATE ticket_types 
                                    SET nama_tiket = ?, harga = ?, deskripsi = ? 
                                    WHERE id = ?");
            $stmt->bind_param('sisi', $nama, $harga, $deskripsi, $id);
        } else {
            $stmt = $conn->prepare("INSERT INTO ticket_types (nama_tiket, harga, deskripsi) 
                                    VALUES (?, ?, ?)");
            $stmt->bind_param('sis', $nama, $harga, $deskripsi);
        }
        $stmt->execute();
        $stmt->close();

        header('Location: manajemen_tiket.php');
        exit;
    }
}

$list = $conn->query("SELECT * FROM ticket_types ORDER BY harga DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen Tiket - SmartTicket</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="main-wrapper">
    <div class="card">
        <div class="app-header">
            <div>
                <div class="badge badge-primary">Admin</div>
                <h1 class="app-title">Manajemen Jenis Tiket</h1>
                <p class="app-subtitle">Tambah, ubah, dan hapus jenis tiket event.</p>
            </div>
            <div>
                <a href="index.php" class="btn btn-outline">← Dashboard</a>
            </div>
        </div>

        <?php if ($message): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($message); ?></div>
        <?php endif; ?>

        <form method="post" class="mb-3">
            <input type="hidden" name="id" value="<?= $editTicket['id'] ?? 0; ?>">

            <div class="form-grid">
                <div class="form-group">
                    <label class="label" for="nama_tiket">Nama Tiket</label>
                    <input class="input" type="text" id="nama_tiket" name="nama_tiket"
                           value="<?= htmlspecialchars($editTicket['nama_tiket'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label class="label" for="harga">Harga (Rp)</label>
                    <input class="input" type="number" id="harga" name="harga" min="0"
                           value="<?= htmlspecialchars($editTicket['harga'] ?? ''); ?>" required>
                </div>
            </div>

            <div class="form-group">
                <label class="label" for="deskripsi">Deskripsi</label>
                <textarea class="input" id="deskripsi" name="deskripsi"
                          rows="3"><?= htmlspecialchars($editTicket['deskripsi'] ?? ''); ?></textarea>
            </div>

            <button type="submit" class="btn btn-primary">
                <?= $editTicket ? 'Update Tiket' : 'Tambah Tiket'; ?>
            </button>
            <?php if ($editTicket): ?>
                <a href="manajemen_tiket.php" class="btn btn-outline">Batal Edit</a>
            <?php endif; ?>
        </form>

        <table class="table">
            <thead>
            <tr>
                <th>ID</th>
                <th>Nama Tiket</th>
                <th>Harga</th>
                <th>Deskripsi</th>
                <th class="text-center">Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php while ($row = $list->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id']; ?></td>
                    <td><strong><?= htmlspecialchars($row['nama_tiket']); ?></strong></td>
                    <td>Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
                    <td><?= nl2br(htmlspecialchars($row['deskripsi'])); ?></td>
                    <td class="text-center">
                        <a class="btn btn-outline" href="manajemen_tiket.php?edit=<?= $row['id']; ?>">Edit</a>
                        <a class="btn btn-outline"
                           href="manajemen_tiket.php?delete=<?= $row['id']; ?>"
                           onclick="return confirm('Yakin ingin menghapus jenis tiket ini?');">
                            Hapus
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
