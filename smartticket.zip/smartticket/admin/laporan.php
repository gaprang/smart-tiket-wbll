<?php
require 'guard.php';
require '../db.php';

// ringkasan total USED
$totalUsed = $conn->query("SELECT COUNT(*) AS jml FROM tickets WHERE status = 'USED'")
                  ->fetch_assoc()['jml'] ?? 0;

// laporan per hari (tiket USED)
$sql = "SELECT DATE(created_at) AS tanggal, COUNT(*) AS jumlah
        FROM tickets
        WHERE status = 'USED' AND created_at IS NOT NULL
        GROUP BY DATE(created_at)
        ORDER BY tanggal DESC
        LIMIT 30";
$list = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Pengunjung - SmartTicket</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="main-wrapper">
    <div class="card">
        <div class="app-header">
            <div>
                <div class="badge badge-primary">Admin</div>
                <h1 class="app-title">Laporan Data Pengunjung</h1>
                <p class="app-subtitle">
                    Berdasarkan tiket yang berstatus <strong>USED</strong> (sudah discan di pintu masuk).
                </p>
            </div>
            <div>
                <a href="index.php" class="btn btn-outline">← Dashboard</a>
            </div>
        </div>

        <div class="summary-box">
            <div class="summary-item">
                <div class="summary-label">Total Tiket Terpakai</div>
                <div class="summary-value"><?= $totalUsed; ?></div>
            </div>
        </div>

        <h3 class="mt-3 mb-2" style="font-size:16px;">Rincian Per Hari</h3>
        <table class="table">
            <thead>
            <tr>
                <th>Tanggal</th>
                <th>Jumlah Pengunjung (USED)</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($list && $list->num_rows): ?>
                <?php while ($row = $list->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['tanggal']; ?></td>
                        <td><?= $row['jumlah']; ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="2" class="text-center text-muted">Belum ada data penggunaan tiket.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
