<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'pelanggan') {
    header('Location: index.php');
    exit;
}
require 'db.php';

$ticketId = isset($_GET['ticket_id']) ? (int)$_GET['ticket_id'] : 0;
$ticket   = null;

if ($ticketId > 0) {
    $stmt = $conn->prepare("SELECT id, nama_tiket, harga, deskripsi FROM ticket_types WHERE id = ?");
    $stmt->bind_param('i', $ticketId);
    $stmt->execute();
    $ticket = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Form Pemesanan - SmartTicket</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="main-wrapper">
    <div class="card">
        <div class="app-header">
            <div>
                <div class="badge badge-primary">Step 1</div>
                <h1 class="app-title">Form Pemesanan Tiket</h1>
                <p class="app-subtitle">Isi data kamu dengan benar, e-tiket akan dikirim & bisa diunduh.</p>
            </div>
            <div>
                <a href="home.php" class="btn btn-outline">← Kembali</a>
            </div>
        </div>

        <?php if (!$ticket): ?>
            <div class="alert alert-danger">
                Jenis tiket tidak ditemukan. Silakan kembali ke halaman utama.
            </div>
        <?php else: ?>
            <div class="summary-box mb-3">
                <div class="summary-item">
                    <div class="summary-label">Jenis Tiket</div>
                    <div class="summary-value"><?= htmlspecialchars($ticket['nama_tiket']); ?></div>
                </div>
                <div class="summary-item">
                    <div class="summary-label">Harga Satuan</div>
                    <div class="summary-value">Rp <?= number_format($ticket['harga'], 0, ',', '.'); ?></div>
                </div>
            </div>

            <form action="proses_bayar.php" method="post">
                <input type="hidden" name="ticket_type_id" value="<?= $ticket['id']; ?>">

                <div class="form-grid">
                    <div class="form-group">
                        <label class="label" for="nama">Nama Lengkap</label>
                        <input class="input" type="text" id="nama" name="nama" required>
                    </div>
                    <div class="form-group">
                        <label class="label" for="email">Email</label>
                        <input class="input" type="email" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label class="label" for="phone">No. HP</label>
                        <input class="input" type="text" id="phone" name="phone" required>
                    </div>
                    <div class="form-group">
                        <label class="label" for="jumlah">Jumlah Tiket</label>
                        <input class="input" type="number" id="jumlah" name="jumlah" min="1" value="1" required>
                    </div>
                </div>

                <div class="alert alert-info mt-2">
                    Pembayaran pada tugas ini <strong>disimulasikan</strong>:
                    setelah klik tombol di bawah, sistem akan menganggap pembayaran berhasil
                    dan langsung membuat e-tiket beserta QR Code.
                </div>

                <div class="mt-3">
                    <button type="submit" class="btn btn-primary">Lanjut & Buat Tiket</button>
                </div>
            </form>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
