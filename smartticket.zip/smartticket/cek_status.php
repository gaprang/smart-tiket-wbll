<?php
require 'db.php';

$statusResult = null;
$tokenInput   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tokenInput = trim($_POST['token'] ?? '');
    if ($tokenInput !== '') {
        $stmt = $conn->prepare("SELECT t.qr_code_token, t.status, t.created_at, o.nama_pelanggan, o.email 
                                FROM tickets t 
                                JOIN orders o ON t.order_id = o.id
                                WHERE t.qr_code_token = ?");
        $stmt->bind_param('s', $tokenInput);
        $stmt->execute();
        $statusResult = $stmt->get_result()->fetch_assoc();
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cek Status Tiket - SmartTicket</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="main-wrapper">
    <div class="card">
        <div class="app-header">
            <div>
                <div class="badge badge-primary">Cek Tiket</div>
                <h1 class="app-title">Cek Status Tiket</h1>
                <p class="app-subtitle">Masukkan kode yang ada di bawah QR Code untuk melihat status tiketmu.</p>
            </div>
            <div>
                <a href="index.php" class="btn btn-outline">← Beranda</a>
            </div>
        </div>

        <form method="post" class="mb-3">
            <div class="form-group">
                <label class="label" for="token">Kode Tiket / QR Token</label>
                <input class="input" type="text" id="token" name="token"
                       placeholder="Contoh: TK-123-ABCDEF-1"
                       value="<?= htmlspecialchars($tokenInput); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Cek Sekarang</button>
        </form>

        <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
            <?php if ($statusResult): ?>
                <div class="summary-box">
                    <div class="summary-item">
                        <div class="summary-label">Nama Pemilik Tiket</div>
                        <div class="summary-value"><?= htmlspecialchars($statusResult['nama_pelanggan']); ?></div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-label">Email</div>
                        <div class="summary-value"><?= htmlspecialchars($statusResult['email']); ?></div>
                    </div>
                    <div class="summary-item">
                        <div class="summary-label">Status Tiket</div>
                        <div class="summary-value">
                            <?php if ($statusResult['status'] === 'VALID'): ?>
                                <span class="chip chip-success">VALID</span>
                            <?php else: ?>
                                <span class="chip chip-warning">USED</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if ($statusResult['created_at']): ?>
                        <div class="summary-item">
                            <div class="summary-label">Dipakai Pada</div>
                            <div class="summary-value"><?= $statusResult['created_at']; ?></div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-danger">
                    Tiket dengan kode tersebut tidak ditemukan.
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
