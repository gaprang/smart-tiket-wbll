<?php
session_start();
require 'db.php';

$orderId = isset($_GET['order_id']) ? (int)$_GET['order_id'] : 0;
if ($orderId <= 0) {
    die('Order ID tidak valid.');
}

// ambil order
$stmt = $conn->prepare("SELECT o.*, t.nama_tiket, t.harga 
                        FROM orders o 
                        JOIN ticket_types t ON o.ticket_type_id = t.id
                        WHERE o.id = ?");
$stmt->bind_param('i', $orderId);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    die('Data pesanan tidak ditemukan.');
}

// ambil tiket
$stmt = $conn->prepare("SELECT id, qr_code_token, status FROM tickets WHERE order_id = ?");
$stmt->bind_param('i', $orderId);
$stmt->execute();
$tickets = $stmt->get_result();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>E-Tiket - SmartTicket</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="main-wrapper">
    <div class="card">
        <div class="app-header">
            <div>
                <div class="badge badge-primary">E-Ticket</div>
                <h1 class="app-title">Tiket Kamu Siap!</h1>
                <p class="app-subtitle">Tunjukkan QR Code di bawah saat masuk ke lokasi acara.</p>
            </div>
            <div>
                <a href="home.php" class="btn btn-outline">Kembali ke Beranda</a>
            </div>
        </div>

        <div class="summary-box">
            <div class="summary-item">
                <div class="summary-label">Nama Pemesan</div>
                <div class="summary-value"><?= htmlspecialchars($order['nama_pelanggan']); ?></div>
            </div>
            <div class="summary-item">
                <div class="summary-label">Email</div>
                <div class="summary-value"><?= htmlspecialchars($order['email']); ?></div>
            </div>
            <div class="summary-item">
                <div class="summary-label">Jenis Tiket</div>
                <div class="summary-value"><?= htmlspecialchars($order['nama_tiket']); ?></div>
            </div>
            <div class="summary-item">
                <div class="summary-label">Total Bayar</div>
                <div class="summary-value">Rp <?= number_format($order['total_harga'], 0, ',', '.'); ?></div>
            </div>
        </div>

        <div class="qr-grid">
            <?php while ($row = $tickets->fetch_assoc()): ?>
                <div class="qr-card">
                    <div class="qr-code-img">
                        <img src="qrcode_generator.php?token=<?= urlencode($row['qr_code_token']); ?>"
                             alt="QR Code" width="130" height="130">
                    </div>
                    <div class="small">
                        Kode: <strong><?= htmlspecialchars($row['qr_code_token']); ?></strong>
                    </div>
                    <div class="small mt-2">
                        Status:
                        <?php if ($row['status'] === 'VALID'): ?>
                            <span class="chip chip-success">VALID</span>
                        <?php else: ?>
                            <span class="chip chip-warning">USED</span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

        <p class="text-muted small mt-3">
            *Kamu juga bisa cek status tiket di menu <strong>Cek Status Tiket</strong> di halaman utama.
        </p>
    </div>
</div>
</body>
</html>
