<?php
session_start();

// kalau sudah login, langsung lempar ke halaman masing-masing
if (isset($_SESSION['role'])) {
    if ($_SESSION['role'] === 'admin') {
        header('Location: admin/index.php');
    } else {
        header('Location: home.php');
    }
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    // login admin
    if ($username === 'admin' && $password === 'admin') {
        $_SESSION['role']     = 'admin';
        $_SESSION['username'] = $username;
        $_SESSION['is_admin'] = true;

        header('Location: admin/index.php');
        exit;
    }
    // login pelanggan
    elseif ($username === 'pelanggan' && $password === 'pelanggan') {
        $_SESSION['role']     = 'pelanggan';
        $_SESSION['username'] = $username;
        $_SESSION['is_admin'] = false;

        header('Location: home.php');
        exit;
    }
    // salah
    else {
        $error = 'Username atau password salah.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - SmartTicket</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="main-wrapper">
    <div class="card">
        <div class="app-header">
            <div>
                <div class="badge badge-primary">SmartTicket</div>
                <h1 class="app-title">Login Sistem Tiket</h1>
                <p class="app-subtitle">
                    Masuk sebagai <strong>pelanggan</strong> atau <strong>admin</strong> untuk melanjutkan.
                </p>
            </div>
        </div>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="post">
            <div class="form-group">
                <label class="label" for="username">Username</label>
                <input class="input" type="text" id="username" name="username" required autofocus>
            </div>

            <div class="form-group">
                <label class="label" for="password">Password</label>
                <input class="input" type="password" id="password" name="password" required>
            </div>

            <div class="mt-3">
                <button type="submit" class="btn btn-primary">Masuk</button>
            </div>
        </form>

        <p class="text-muted small mt-3">
            *Untuk demo tugas:<br>
            - Pelanggan: <strong>username</strong> = <code>pelanggan</code>, <strong>password</strong> = <code>pelanggan</code><br>
            - Admin: <strong>username</strong> = <code>admin</code>, <strong>password</strong> = <code>admin</code>
        </p>
    </div>
</div>
</body>
</html>
