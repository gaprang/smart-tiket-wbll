<?php
session_start();
require 'db.php';

// pastikan yang boleh masuk cuma pelanggan
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'pelanggan') {
    header('Location: index.php');
    exit;
}

// ambil semua jenis tiket
$result = $conn->query("SELECT id, nama_tiket, harga, deskripsi FROM ticket_types ORDER BY harga DESC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>SmartTicket - Pemesanan Tiket Online</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="main-wrapper">
    <div class="card">
        <div class="app-header">
            <div>
                <div class="badge badge-primary">Online Ticketing</div>
                <h1 class="app-title">SmartTicket</h1>
                <p class="app-subtitle">
                    Pesan tiket event kamu secara cepat, rapi, dan tanpa ribet.
                </p>
            </div>
            <div>
                <a href="cek_status.php" class="btn btn-outline">Cek Status Tiket</a>
                <a href="logout.php" class="btn btn-outline" style="margin-left:6px;">Logout</a>
            </div>
        </div>

        <div class="nav-top">
            <span class="text-muted small">
                Login sebagai: <strong><?= htmlspecialchars($_SESSION['username'] ?? 'pelanggan'); ?></strong>
            </span>
        </div>

        <table class="table">
            <thead>
            <tr>
                <th>Jenis Tiket</th>
                <th>Deskripsi</th>
                <th class="text-right">Harga</th>
                <th class="text-center">Aksi</th>
            </tr>
            </thead>
            <tbody>
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($row['nama_tiket']); ?></strong></td>
                        <td><?= nl2br(htmlspecialchars($row['deskripsi'] ?? '')); ?></td>
                        <td class="text-right">Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
                        <td class="text-center">
                            <a class="btn btn-primary"
                               href="pemesanan.php?ticket_id=<?= $row['id']; ?>">
                                Pesan
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="4" class="text-center text-muted">
                        Belum ada jenis tiket. Silakan tambahkan dari halaman Admin.
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>

        <p class="text-muted small mt-3">
            *Ini contoh project tugas – alur pembayaran bisa disimulasikan saja (langsung dianggap Lunas).
        </p>
    </div>
</div>
</body>
</html>
