<?php
// db.php
$host     = 'localhost';
$user     = 'root';
$password = ''; // default XAMPP
$dbname   = 'smartticket';

$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die('Koneksi gagal: ' . $conn->connect_error);
}

// optional: set timezone
date_default_timezone_set('Asia/Jakarta');
?>
