<?php
require 'db.php';

header('Content-Type: application/json; charset=utf-8');

$token = trim($_GET['token'] ?? $_POST['token'] ?? '');

if ($token === '') {
    echo json_encode([
        'status'  => 'error',
        'message' => 'Token tidak boleh kosong'
    ]);
    exit;
}

// cari tiket
$stmt = $conn->prepare("SELECT id, status FROM tickets WHERE qr_code_token = ?");
$stmt->bind_param('s', $token);
$stmt->execute();
$ticket = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$ticket) {
    echo json_encode([
        'status'  => 'invalid',
        'message' => 'Tiket tidak ditemukan'
    ]);
    exit;
}

if ($ticket['status'] === 'USED') {
    echo json_encode([
        'status'  => 'invalid',
        'message' => 'Tiket sudah dipakai sebelumnya'
    ]);
    exit;
}

// kalau VALID → ubah jadi USED
$now  = date('Y-m-d H:i:s');
$id   = (int)$ticket['id'];

$stmt = $conn->prepare("UPDATE tickets SET status = 'USED', created_at = ? WHERE id = ?");
$stmt->bind_param('si', $now, $id);
$stmt->execute();
$stmt->close();

echo json_encode([
    'status'  => 'valid',
    'message' => 'Akses diizinkan, tiket sah'
]);
